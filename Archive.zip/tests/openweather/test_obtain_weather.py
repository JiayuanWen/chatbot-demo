from utils.openweather.obtain_weather import get_weather_desc

get_weather_desc("Queens")
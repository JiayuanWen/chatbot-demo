from utils.openai.embedding import text_embedding
from utils.openai.embedding import cos_similarity
from utils.openai.embedding import text_ranking

text_embedding(["Hello", "How"])
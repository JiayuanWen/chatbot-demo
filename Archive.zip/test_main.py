from tests.openweather import test_obtain_weather

if __name__ == "__main__":
    test_obtain_weather()